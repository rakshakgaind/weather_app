package com.project.weather.model

interface IViewProgress {

    fun showProgress(enabled: Boolean)
}